import BaseSource from './base.js';
import { log } from "../utils/log-util.js";
import { buildQueryString, httpGet} from "../utils/http-util.js";
import { printFirst200Chars, titleMatches, getExplicitSeasonNumber, extractSeasonNumberFromAnimeTitle, extractEpisodeNumberFromTitle, extractAnimeTitle } from "../utils/common-util.js";
import { md5, convertToAsciiSum, decodeHtmlEntities, base64ToBytes, decompressBrotli, utf8BytesToString } from "../utils/codec-util.js";
import { generateValidStartDate } from "../utils/time-util.js";
import { addAnime, removeEarliestAnime } from "../utils/cache-util.js";
import { globals } from '../configs/globals.js';
import { SegmentListResponse } from '../models/dandan-model.js';

// =====================
// 获取爱奇艺弹幕
// =====================
export default class IqiyiSource extends BaseSource {
  // 爱奇艺 API 签名相关常量
  static XOR_KEY = 0x75706971676c;
  static SECRET_KEY = "howcuteitis";
  static KEY_NAME = "secret_key";

  /**
   * 搜索爱奇艺内容
   * @param {string} keyword - 搜索关键词
   * @returns {Promise<Array>} 搜索结果数组
   */
  async search(keyword) {
    try {
      log("info", `[iqiyi] 开始搜索: ${keyword}`);

      // 使用桌面版 API 搜索
      const params = {
        key: keyword,
        current_page: '1',
        mode: '1',
        source: 'input',
        suggest: '',
        pcv: '13.074.22699',
        version: '13.074.22699',
        pageNum: '1',
        pageSize: '25',
        pu: '',
        u: 'f6440fc5d919dca1aea12b6aff56e1c7',
        scale: '200',
        token: '',
        userVip: '0',
        conduit: '',
        vipType: '-1',
        os: '',
        osShortName: 'win10',
        dataType: '',
        appMode: '',
        ad: JSON.stringify({"lm":3,"azd":1000000000951,"azt":733,"position":"feed"}),
        adExt: JSON.stringify({"r":"2.1.5-ares6-pure"})
      };

      // 手动构建 URL（httpGet 不支持 params 选项）
      const queryString = buildQueryString(params);
      const url = `https://mesh.if.iqiyi.com/portal/lw/search/homePageV3?${queryString}`;

      const doSearch = async (bypassCache = false) => {
        const resp = await httpGet(url, {
          headers: {
            'accept': '*/*',
            'origin': 'https://www.iqiyi.com',
            'referer': 'https://www.iqiyi.com/',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
          },
          bypassCache
        });
        if (!resp || !resp.data) return null;
        return typeof resp.data === "string" ? JSON.parse(resp.data) : resp.data;
      };

      // 搜索接口风控时延迟重试，最多重试三次
      const MAX_RETRIES = 3;
      let data = await doSearch();
      for (let attempt = 0; attempt < MAX_RETRIES && (!data || data.code === "-1"); attempt++) {
        const reason = !data ? "搜索响应为空" : `搜索接口风控 (code=${data.code})`;
        log("info", `[iqiyi] ${reason}，等待 3 秒后重试 (${attempt + 1}/${MAX_RETRIES})`);
        await new Promise(r => setTimeout(r, 3000));
        data = await doSearch(true);
      }

      if (!data) {
        log("info", "[iqiyi] 搜索响应为空");
        return [];
      }

      if (data.code === "-1") {
        log("info", "[iqiyi] 搜索接口风控 (code=-1)，重试后仍失败");
        log("info", `[iqiyi] 搜索原始数据: ${JSON.stringify(data)}`);
        return [];
      }

      if (!data.data || !data.data.templates) {
        log("info", "[iqiyi] 搜索无结果");
        log("info", `[iqiyi] 搜索原始数据: ${JSON.stringify(data)}`);
        return [];
      }

      // 处理搜索结果
      const results = [];
      const templates = data.data.templates;

      for (const template of templates) {
        let albumsToProcess = [];

        // 优先处理意图卡片 (template 112)
        if (template.template === 112 && template.intentAlbumInfos) {
          log("info", `[iqiyi] 找到意图卡片 (template 112)，处理 ${template.intentAlbumInfos.length} 个结果`);
          albumsToProcess = template.intentAlbumInfos;
        }
        // 然后处理普通结果卡片
        else if ([101, 102, 103].includes(template.template) && template.albumInfo) {
          log("info", `[iqiyi] 找到普通结果卡片 (template ${template.template})`);
          albumsToProcess = [template.albumInfo];
        }

        for (const album of albumsToProcess) {
          const filtered = this._filterIqiyiSearchItem(album, keyword);
          if (filtered) {
            results.push(filtered);
          }
        }
      }

      log("info", `[iqiyi] 搜索找到 ${results.length} 个有效结果`);
      return results;

    } catch (error) {
      log("error", "[iqiyi] 搜索出错:", error.message);
      return [];
    }
  }

  /**
   * 过滤爱奇艺搜索项
   * @param {Object} album - 搜索结果专辑信息
   * @param {string} keyword - 搜索关键词
   * @returns {Object|null} 过滤后的结果
   */
  _filterIqiyiSearchItem(album, keyword) {
    if (!album.title) {
      return null;
    }

    // 过滤外站付费播放
    if (album.btnText === '外站付费播放') {
      log("info", `[iqiyi] 过滤掉外站付费播放内容: ${album.title}`);
      return null;
    }

    // 提取媒体类型
    const channel = album.channel || "";
    let mediaType = "电视剧"; // 默认类型

    if (channel.includes("电影")) {
      mediaType = "电影";
    } else if (channel.includes("动漫")) {
      mediaType = "动漫";
    } else if (channel.includes("综艺")) {
      mediaType = "综艺";
    } else if (channel.includes("纪录片")) {
      mediaType = "纪录片";
    } else if (channel.includes("电视剧")) {
      mediaType = "电视剧";
    } else {
      // 只保留支持的类型：电影、电视剧、动漫、综艺、纪录片
      return null;
    }

    // 提取 3D 与 2D 属性标签并追加至媒体类型
    let is3D = false;
    let is2D = false;
    if (album.metaTags && Array.isArray(album.metaTags)) {
        album.metaTags.forEach(tag => {
            if (tag.name === '3D') is3D = true;
            if (tag.name === '2D') is2D = true;
        });
    }
    if (album.baseTags && Array.isArray(album.baseTags)) {
        album.baseTags.forEach(tag => {
            if (tag.value === '3D') is3D = true;
            if (tag.value === '2D') is2D = true;
        });
    }
    if (is3D) {
        mediaType = "3D" + mediaType;
    } else if (is2D) {
        mediaType = "2D" + mediaType;
    }

    // 电影类型：使用 qipuId 作为 mediaId
    if (mediaType.includes("电影")) {
      const qipuId = album.qipuId || album.playQipuId;
      if (!qipuId) {
        log("info", `[iqiyi] 电影缺少 qipuId: ${album.title}`);
        return null;
      }

      // 提取年份（普通结果卡片在 year 字段，意图聚合卡片 template 112 无 year 字段，年份在 superscript 角标）
      let year = null;
      const yearStr = (album.year && (album.year.value || album.year.name)) || album.superscript;
      if (yearStr && typeof yearStr === 'string' && /^\d{4}$/.test(yearStr)) {
        year = parseInt(yearStr);
      }

      // 清理标题
      const cleanedTitle = album.title.replace(/<[^>]+>/g, '').replace(/:/g, '：');

      return {
        provider: "iqiyi",
        mediaId: `movie_${qipuId}`, // 使用特殊前缀标识电影
        title: cleanedTitle,
        type: mediaType,
        year: year,
        imageUrl: album.img || album.imgH,
        episodeCount: 1, // 电影只有1集
        _qipuId: qipuId // 保存原始 qipuId 供后续使用
      };
    }

    // 非电影类型：从 pageUrl 提取 link_id
    const url = album.pageUrl;
    if (!url) {
      log("info", `[iqiyi] 非电影内容缺少 pageUrl: ${album.title}`);
      return null;
    }

    const linkIdMatch = url.match(/v_(\w+?)\.html/);
    if (!linkIdMatch) {
      log("info", `[iqiyi] 无法从 pageUrl 提取 link_id: ${url}`);
      return null;
    }
    const linkId = linkIdMatch[1];

    // 提取年份（普通结果卡片在 year 字段，意图聚合卡片 template 112 无 year 字段，年份在 superscript 角标）
    let year = null;
    const yearStr = (album.year && (album.year.value || album.year.name)) || album.superscript;
    if (yearStr && typeof yearStr === 'string' && /^\d{4}$/.test(yearStr)) {
      year = parseInt(yearStr);
    }

    // 提取分集数
    let episodeCount = null;
    if (album.videos && album.videos.length > 0) {
      episodeCount = album.videos.length;
    } else if (album.subscriptContent) {
      // 从 subscriptContent 中提取集数
      const countMatch = album.subscriptContent.match(/(?:更新至|全|共)\s*(\d+)\s*(?:集|话|期)/);
      if (countMatch) {
        episodeCount = parseInt(countMatch[1]);
      } else {
        const simpleMatch = album.subscriptContent.trim().match(/^(\d+)$/);
        if (simpleMatch) {
          episodeCount = parseInt(simpleMatch[1]);
        }
      }
    }

    // 清理标题
    const cleanedTitle = album.title.replace(/<[^>]+>/g, '').replace(/:/g, '：');

    return {
      provider: "iqiyi",
      mediaId: linkId,
      title: cleanedTitle,
      type: mediaType,
      year: year,
      imageUrl: album.img || album.imgH,
      episodeCount: episodeCount
    };
  }

  /**
   * 获取分集列表
   * @param {string} id - 视频 ID (link_id 或 movie_qipuId)
   * @param {number|null} querySeason - 目标季，指定时只获取该季分集
   * @param {Map|null} seasonAlbumCache - 跨多次调用共享的分季数据缓存，避免同一 album 重复请求
   * @returns {Promise<Array>} 分集列表
   */
  async getEpisodes(id, querySeason = null, seasonAlbumCache = null, inlinedAlbumIds = null, baseInfoCache = null) {
    try {
      log("info", `[iqiyi] 获取分集列表: media_id=${id}`);

      // 检查是否是电影类型（以 movie_ 开头）
      if (id.startsWith('movie_')) {
        const qipuId = id.substring(6); // 移除 "movie_" 前缀
        log("info", `[iqiyi] 电影类型，调用 base_info API 获取视频ID: qipuId=${qipuId}`);

        // 调用 base_info API 获取电影详情
        const videoId = await this._getMovieVideoId(qipuId);
        if (!videoId) {
          log("error", `[iqiyi] 无法获取电影的视频ID: qipuId=${qipuId}`);
          return [];
        }

        log("info", `[iqiyi] 电影视频ID: ${videoId}`);
        return [{
          id: videoId,
          title: "正片",
          order: 1,
          link: `https://www.iqiyi.com/v_${videoId}.html`
        }];
      }

      // 将 video_id 转换为 entity_id
      const entityId = /^\d+$/.test(id) ? id : this._videoIdToEntityId(id);
      if (!entityId) {
        log("error", `[iqiyi] 无法将 media_id '${id}' 转换为 entity_id`);
        return [];
      }

      // 分集列表数据；本次搜索已在 handleAnimes 中统一拉取时直接复用，避免重复请求
      let data;
      if (baseInfoCache && baseInfoCache.has(id)) {
        data = baseInfoCache.get(id);
      } else {
        data = await this._fetchBaseInfoData(entityId);
      }
      if (!data || data.status_code !== 0 || !data.data || !data.data.template) {
        return [];
      }

      // 第四步：解析分集数据
      const allEpisodes = [];
      const tabs = data.data.template.tabs || [];

      if (tabs.length === 0) {
        log("info", "[iqiyi] 未找到分集标签页");
        return [];
      }

      const blocks = tabs[0].blocks || [];
      let foundEpisodes = false;
      const fetchedSeasons = seasonAlbumCache || new Map();

      for (const block of blocks) {
        // 查找 video_list 类型的块（新版API）
        if (block.bk_type === "video_list" && block.data?.data) {
          log("info", `[iqiyi] 找到 video_list 类型的分集数据块, bk_id: ${block.bk_id}`);

          // 检查是否是分集选择器块
          if (!block.tag || !block.tag.includes("episodes")) {
            log("info", `[iqiyi] 跳过非分集块: ${block.bk_id}`);
            continue;
          }

          foundEpisodes = true;

          const dataGroups = block.data.data;
          if (!Array.isArray(dataGroups)) {
            log("warn", "[iqiyi] data.data 不是数组，跳过此块");
            continue;
          }

          for (const group of dataGroups) {
            if (!group.videos || !Array.isArray(group.videos)) continue;

            // 遍历每个年份/季度分组
            for (const videoGroup of group.videos) {
              if (!videoGroup.data || !Array.isArray(videoGroup.data)) continue;

              // 处理每个分集
              for (const epData of videoGroup.data) {
                // 只处理正片内容 (content_type === 1)
                if (epData.content_type !== 1) continue;

                const playUrl = epData.play_url || "";
                const tvidMatch = playUrl.match(/tvid=(\d+)/);
                if (!tvidMatch) continue;

                const tvid = tvidMatch[1];
                const title = this._buildEpisodeTitle(epData);

                const order = epData.album_order;
                const pageUrl = epData.page_url;

                if (tvid && title && pageUrl) {
                  allEpisodes.push({
                    id: tvid,
                    title: title,
                    order: order !== undefined ? order : allEpisodes.length,
                    link: pageUrl
                  });
                }
              }
            }
          }
        }
        // 兼容旧版 API 的 album_episodes 类型
        else if (block.bk_type === "album_episodes" && block.data?.data) {
          log("info", "[iqiyi] 找到 album_episodes 类型的分集数据块");
          foundEpisodes = true;

          const episodeGroups = block.data.data;
          for (const group of episodeGroups) {
            // 指定季时只处理目标季的分季组，避免拉取并合并无关季的分集
            if (querySeason !== null && group.tab_name) {
              const groupSeason = getExplicitSeasonNumber(group.tab_name);
              if (groupSeason !== null && groupSeason !== querySeason) continue;
            }

            let videosData = group.videos;

            // 分季数据是 URL 时需额外请求；以 album_id 为键复用已获取或正在获取的请求，
            // 避免同一次搜索内同一分季被并发或重复请求
            if (typeof videosData === 'string') {
              // 该季的 album_id 已通过其它结果的 album_episodes 内联数据获取时，无需再请求分季URL
              const groupAlbumId = group.entity_id ? String(group.entity_id) : (videosData.match(/album_id=(\d+)/)?.[1] || videosData);
              if (inlinedAlbumIds && inlinedAlbumIds.has(groupAlbumId)) {
                log("info", `[iqiyi] 该季分集已通过内联数据获取，跳过分季URL: ${groupAlbumId}`);
                continue;
              }
              const albumIdKey = groupAlbumId;
              let seasonPromise = fetchedSeasons.get(albumIdKey);
              if (!seasonPromise) {
                seasonPromise = (async () => {
                  log("info", `[iqiyi] 发现分季URL，正在获取: ${videosData}`);
                  const seasonResponse = await httpGet(videosData);
                  return typeof seasonResponse.data === "string" ? JSON.parse(seasonResponse.data) : seasonResponse.data;
                })();
                fetchedSeasons.set(albumIdKey, seasonPromise);
              } else {
                log("info", `[iqiyi] 分季URL已获取过，跳过重复请求: ${albumIdKey}`);
              }
              try {
                videosData = await seasonPromise;
              } catch (error) {
                fetchedSeasons.delete(albumIdKey);
                log("error", `[iqiyi] 获取分季数据失败: ${error.message}`);
                continue;
              }
            }

            // 处理分页数据
            if (videosData && typeof videosData === 'object' && videosData.feature_paged) {
              for (const pageKey in videosData.feature_paged) {
                const pagedList = videosData.feature_paged[pageKey];
                for (const epData of pagedList) {
                  if (epData.content_type !== 1) continue;

                  const playUrl = epData.play_url || "";
                  const tvidMatch = playUrl.match(/tvid=(\d+)/);
                  if (!tvidMatch) continue;

                  const tvid = tvidMatch[1];
                  const title = this._buildEpisodeTitle(epData);

                  const order = epData.album_order;
                  const pageUrl = epData.page_url;

                  if (tvid && title && order && pageUrl) {
                    allEpisodes.push({
                      id: tvid,
                      title: title,
                      order: order,
                      link: pageUrl
                    });
                  }
                }
              }
            }
          }
        }
      }

      if (!foundEpisodes) {
        log("info", "[iqiyi] 未找到分集数据块");
        return [];
      }

      // 去重并排序
      const uniqueEpisodes = Array.from(
        new Map(allEpisodes.map(ep => [ep.id, ep])).values()
      );
      uniqueEpisodes.sort((a, b) => a.order - b.order);

      log("info", `[iqiyi] 成功获取 ${uniqueEpisodes.length} 个分集`);
      return uniqueEpisodes;

    } catch (error) {
      log("error", "[iqiyi] 获取分集出错:", error.message);
      return [];
    }
  }

  /**
   * 请求分集列表接口并解析响应，接口返回空响应或结构残缺时最多重试两次
   * @param {string} entityId - 实体 id
   * @returns {Promise<Object|null>} 解析后的响应数据，失败返回 null
   */
  async _fetchBaseInfoData(entityId) {
    const params = {
      entity_id: entityId,
      device_id: 'qd5fwuaj4hunxxdgzwkcqmefeb3ww5hx',
      auth_cookie: '',
      user_id: '0',
      vip_type: '-1',
      vip_status: '0',
      conduit_id: '',
      pcv: '13.082.22866',
      app_version: '13.082.22866',
      ext: '',
      app_mode: 'standard',
      scale: '100',
      timestamp: String(Date.now()),
      src: 'pca_tvg',
      os: '',
      ad_ext: '{"r":"2.2.0-ares6-pure"}'
    };
    params.sign = this._createSign(params);

    const queryString = buildQueryString(params);
    const url = `https://www.iqiyi.com/prelw/tvg/v2/lw/base_info?${queryString}`;

    // base_info 接口可能返回空响应或结构残缺的响应，此处最多重试两次再放弃
    const MAX_EPISODE_RETRIES = 2;
    const fetchEpisodeData = async (bypassCache = false) => {
      try {
        const resp = await httpGet(url, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Referer': 'https://www.iqiyi.com/'
          },
          bypassCache
        });
        if (!resp || !resp.data) return null;
        return typeof resp.data === "string" ? JSON.parse(resp.data) : resp.data;
      } catch (error) {
        log("error", `[iqiyi] 获取分集列表请求失败: ${error.message}`);
        return null;
      }
    };

    let data = await fetchEpisodeData();
    for (let attempt = 0; attempt < MAX_EPISODE_RETRIES && (!data || data.status_code !== 0 || !data.data || !data.data.template); attempt++) {
      log("info", `[iqiyi] 分集接口返回异常${data ? ` (status_code: ${data.status_code})` : " (响应为空或解析失败)"}，等待 3 秒后重试 (${attempt + 1}/${MAX_EPISODE_RETRIES})`);
      await new Promise(r => setTimeout(r, 3000));
      data = await fetchEpisodeData(true);
    }

    if (!data || data.status_code !== 0 || !data.data || !data.data.template) {
      log("error", `[iqiyi] 获取分集列表失败: ${data ? `status_code: ${data.status_code}` : "响应为空或解析失败"}`);
      return null;
    }
    return data;
  }

  /**
   * 组装分集标题：取接口的分集名，并在标题末尾补上副标题
   * @param {object} epData - 分集原始数据
   * @returns {string} 分集标题
   */
  _buildEpisodeTitle(epData) {
    let title = epData.short_display_name || epData.title || "未知分集";
    const subtitle = epData.subtitle;
    if (subtitle && !title.includes(subtitle)) {
      title = `${title} ${subtitle}`;
    }
    return title;
  }

  /**
   * 补齐分集标题缺失的集数，集数置于作品名后面，与接口自带集数的分集保持同一格式
   * @param {string} title - 分集标题
   * @param {string} animeTitle - 所属作品名
   * @param {number} order - 分集序号
   * @returns {string} 含集数的分集标题
   */
  _ensureEpisodeNumber(title, animeTitle, order) {
    if (extractEpisodeNumberFromTitle(title) !== null) return title;
    // 缺少分集序号时无法补全，保持标题原样
    if (order === undefined || order === null || order === "") return title;
    // 作品名去掉年份与类型后缀后再与分集标题比对，避免拼接出来的名字对不上
    const animeName = extractAnimeTitle(animeTitle || "");
    const prefix = animeName && title.startsWith(animeName) ? animeName : "";
    const rest = prefix ? title.slice(prefix.length).trim() : title;
    return prefix
      ? `${prefix} 第${order}集 ${rest}`.trim()
      : `第${order}集 ${rest}`.trim();
  }

  /**
   * 全季搜索时统一拉取各结果的分集列表，收集其中以内联方式返回的季 album_id；
   * 这些季无需再经分季URL获取，供 getEpisodes 判断跳过对应请求
   * @param {Array} animes - 搜索结果数组
   * @param {Map} baseInfoCache - 复用已拉取的分集列表数据，避免重复请求
   * @returns {Promise<Set<string>>} 已被内联的季 album_id 集合
   */
  async _collectInlinedAlbumIds(animes, baseInfoCache) {
    const inlined = new Set();
    await Promise.all(animes.map(async (anime) => {
      if (anime.mediaId.startsWith('movie_')) return;
      const entityId = /^\d+$/.test(anime.mediaId) ? anime.mediaId : this._videoIdToEntityId(anime.mediaId);
      if (!entityId) return;
      const data = await this._fetchBaseInfoData(entityId);
      baseInfoCache.set(anime.mediaId, data);
      if (!data || !data.data || !data.data.template) return;
      const tabs = data.data.template.tabs || [];
      if (tabs.length === 0) return;
      for (const block of (tabs[0].blocks || [])) {
        if (block.bk_type === 'album_episodes' && block.data?.data) {
          for (const group of block.data.data) {
            if (group.videos && typeof group.videos === 'object' && group.videos.feature_paged && group.entity_id) {
              inlined.add(String(group.entity_id));
            }
          }
        }
      }
    }));
    return inlined;
  }

  /**
   * 获取电影的视频ID（从 qipuId 获取正确的 video_id）
   * @param {string} qipuId - 电影的 qipuId
   * @returns {Promise<string|null>} 视频ID
   */
  async _getMovieVideoId(qipuId) {
    try {
      // 构建 base_info API 请求参数
      const params = {
        entity_id: qipuId,
        device_id: 'qd5fwuaj4hunxxdgzwkcqmefeb3ww5hx',
        auth_cookie: '',
        user_id: '0',
        vip_type: '-1',
        vip_status: '0',
        conduit_id: '',
        pcv: '13.103.23529',
        app_version: '13.103.23529',
        ext: '',
        app_mode: 'standard',
        scale: '125',
        timestamp: String(Date.now()),
        src: 'pca_tvg',
        os: '',
        ad_ext: '{"r":"2.5.0-ares6-pure"}'
      };

      // 生成签名（使用与 getEpisodes 相同的方法）
      params.sign = this._createSign(params);

      // 构建 URL
      const queryString = buildQueryString(params);
      const url = `https://mesh.if.iqiyi.com/tvg/v2/lw/base_info?${queryString}`;

      log("info", `[iqiyi] 请求电影详情: ${url}`);

      const response = await httpGet(url, {
        headers: {
          'accept': '*/*',
          'origin': 'https://www.iqiyi.com',
          'referer': 'https://www.iqiyi.com/',
          'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
      });

      if (!response || !response.data) {
        log("error", "[iqiyi] base_info API 响应为空");
        return null;
      }

      const data = typeof response.data === "string" ? JSON.parse(response.data) : response.data;

      // 从响应中提取视频ID
      // 尝试多个可能的路径
      if (data.data && data.data.base_data) {
        const baseData = data.data.base_data;

        // 尝试 1: 从 share_url 中提取（旧格式 v_xxx.html）
        if (baseData.share_url) {
          const match = baseData.share_url.match(/v_(\w+)\.html/);
          if (match) {
            log("info", `[iqiyi] 从 share_url 提取视频ID: ${match[1]}`);
            return match[1];
          }
        }

        // 尝试 2: 从 page_url 中提取
        if (baseData.page_url) {
          const match = baseData.page_url.match(/v_(\w+)\.html/);
          if (match) {
            log("info", `[iqiyi] 从 page_url 提取视频ID: ${match[1]}`);
            return match[1];
          }
        }
      }

      // 所有尝试均失败，使用 qipuId（entity_id）作为视频ID
      log("info", `[iqiyi] 响应中未找到 v_xxx 格式视频ID，使用 entity_id: ${qipuId}`);
      log("info", `[iqiyi] 响应数据结构: ${JSON.stringify(data).substring(0, 1000)}...`);
      return qipuId;

    } catch (error) {
      log("error", `[iqiyi] 获取电影视频ID时出错: ${error.message}`);
      return null;
    }
  }

  /**
   * 将 video_id 转换为 entity_id
   * @param {string} videoId - 视频 ID
   * @returns {string|null} entity_id
   */
  _videoIdToEntityId(videoId) {
    try {
      const base36Decoded = parseInt(videoId, 36);
      const xorResult = this._xorOperation(base36Decoded);
      const finalResult = xorResult < 900000 ? 100 * (xorResult + 900000) : xorResult;
      return String(finalResult);
    } catch (error) {
      log("error", `[iqiyi] 将 video_id '${videoId}' 转换为 entity_id 时出错: ${error.message}`);
      return null;
    }
  }

  /**
   * 异或运算
   * @param {number} num - 输入数字
   * @returns {number} 异或结果
   */
  _xorOperation(num) {
    const numBinary = num.toString(2);
    const keyBinary = IqiyiSource.XOR_KEY.toString(2);
    const numBits = numBinary.split('').reverse();
    const keyBits = keyBinary.split('').reverse();
    const resultBits = [];
    const maxLen = Math.max(numBits.length, keyBits.length);

    for (let i = 0; i < maxLen; i++) {
      const numBit = i < numBits.length ? numBits[i] : '0';
      const keyBit = i < keyBits.length ? keyBits[i] : '0';
      if (numBit === '1' && keyBit === '1') {
        resultBits.push('0');
      } else if (numBit === '1' || keyBit === '1') {
        resultBits.push('1');
      } else {
        resultBits.push('0');
      }
    }

    const resultBinary = resultBits.reverse().join('');
    return resultBinary ? parseInt(resultBinary, 2) : 0;
  }

  /**
   * 为 API 生成签名
   * @param {Object} params - 请求参数
   * @returns {string} MD5 签名
   */
  _createSign(params) {
    const cleanParams = {};
    for (const key in params) {
      if (key !== 'sign') {
        cleanParams[key] = params[key];
      }
    }

    const sortedKeys = Object.keys(cleanParams).sort();
    const paramParts = [];
    for (const key of sortedKeys) {
      const value = cleanParams[key] === null || cleanParams[key] === undefined ? "" : cleanParams[key];
      paramParts.push(`${key}=${value}`);
    }

    const paramString = paramParts.join("&");
    const signString = `${paramString}&${IqiyiSource.KEY_NAME}=${IqiyiSource.SECRET_KEY}`;
    return md5(signString).toUpperCase();
  }

  /**
   * 处理搜索结果
   * @param {Array} sourceAnimes 原始数据
   * @param {string} queryTitle 关键词
   * @param {Array} curAnimes 结果池
   * @param {Map|null} detailStore 详情缓存
   * @param {number|null} querySeason 目标季度
   */
  async handleAnimes(sourceAnimes, queryTitle, curAnimes, detailStore = null, querySeason = null) {
    const tmpAnimes = [];

    // 添加错误处理，确保sourceAnimes是数组
    if (!sourceAnimes || !Array.isArray(sourceAnimes)) {
      log("error", "[iqiyi] sourceAnimes is not a valid array");
      return [];
    }

    let filteredAnimes = sourceAnimes.filter(s => titleMatches(s.title, queryTitle, querySeason));

    // 提取搜索词中的明确季度信息或使用传入的季度参数
    const resolvedQuerySeason = querySeason !== null ? querySeason : getExplicitSeasonNumber(queryTitle);

    // 初始列表预过滤机制：若用户指定了季度，优先检查初始结果中是否已包含匹配项
    if (resolvedQuerySeason !== null) {
      const seasonFiltered = filteredAnimes.filter(anime => {
        const s = extractSeasonNumberFromAnimeTitle(anime.title).season;
        return s === resolvedQuerySeason || (resolvedQuerySeason === 1 && s === null);
      });

      // 如果已命中目标，减少详情请求量
      if (seasonFiltered.length > 0) {
        filteredAnimes = seasonFiltered;
        log("info", `[iqiyi] 结果已命中目标季(第${resolvedQuerySeason}季)，跳过非目标季相关请求`);
      }
    }

    // 跨多个搜索结果共享分季数据缓存，避免同一 album 的分季URL被重复请求
    const seasonAlbumCache = new Map();

    // 全季搜索时先统一拉取各结果的分集列表，收集已被内联的季 album_id；
    // 这些季无需再经分季URL获取，后续处理各结果时据此跳过对应请求
    let inlinedAlbumIds = null;
    const baseInfoCache = new Map();
    if (resolvedQuerySeason === null) {
      inlinedAlbumIds = await this._collectInlinedAlbumIds(filteredAnimes, baseInfoCache);
    }

    const processIqiyiAnimes = await Promise.all(filteredAnimes.map(async (anime) => {
        try {
          const eps = await this.getEpisodes(anime.mediaId, resolvedQuerySeason, seasonAlbumCache, inlinedAlbumIds, baseInfoCache);

          // 格式化分集列表
          const links = [];
          for (const ep of eps) {
            const fullUrl = ep.link || `https://www.iqiyi.com/v_${anime.mediaId}.html`;
            links.push({
              "name": ep.order.toString(),
              "url": fullUrl,
              "title": `【qiyi】 ${this._ensureEpisodeNumber(ep.title, anime.title, ep.order)}`
            });
          }

          if (links.length > 0) {
            const numericAnimeId = convertToAsciiSum(anime.mediaId);
            const transformedAnime = {
              animeId: numericAnimeId,
              bangumiId: anime.mediaId,
              animeTitle: `${anime.title}(${anime.year || 'N/A'})【${anime.type}】from iqiyi`,
              type: anime.type,
              typeDescription: anime.type,
              imageUrl: anime.imageUrl,
              startDate: generateValidStartDate(anime.year),
              episodeCount: links.length,
              rating: 0,
              isFavorited: true,
              source: "iqiyi",
            };

            tmpAnimes.push(transformedAnime);
            addAnime({...transformedAnime, links: links}, detailStore);

            if (globals.animes.length > globals.MAX_ANIMES) {
              removeEarliestAnime();
            }
          }
        } catch (error) {
          log("error", `[iqiyi] Error processing anime: ${error.message}`);
        }
      })
    );

    this.sortAndPushAnimesByYear(tmpAnimes, curAnimes);
    return processIqiyiAnimes;
  }

  async getEpisodeDanmu(id) {
    log("info", "[iqiyi] 开始从本地请求爱奇艺弹幕...", id);

    // 获取页面标题
    let res;
    try {
      res = await httpGet(id, {
        headers: {
          "Content-Type": "application/json",
          "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      });
    } catch (error) {
      log("error", "[iqiyi] 请求页面失败:", error);
      return [];
    }

    // 使用正则表达式提取 <title> 标签内容
    const titleMatch = res.data.match(/<title[^>]*>(.*?)<\/title>/i);
    const title = titleMatch ? titleMatch[1].split("_")[0] : "未知标题";
    log("info", `[iqiyi] 标题: ${title}`);

    // 获取弹幕分段数据
    const segmentResult = await this.getEpisodeDanmuSegments(id);
    if (!segmentResult || !segmentResult.segmentList || segmentResult.segmentList.length === 0) {
      return [];
    }

    const segmentList = segmentResult.segmentList;
    log("info", `[iqiyi] 弹幕分段数量: ${segmentList.length}`);

    // 创建请求Promise数组
    const promises = [];
    for (const segment of segmentList) {
      promises.push(this.getEpisodeSegmentDanmu(segment));
    }

    // 解析弹幕数据
    let contents = [];
    try {
      const results = await Promise.allSettled(promises);
      const datas = results
        .filter(result => result.status === "fulfilled")
        .map(result => result.value)
        .filter(data => data !== null); // 过滤掉null值

      datas.forEach(data => {
        contents.push(...data);
      });
    } catch (error) {
      log("error", "[iqiyi] 解析弹幕数据失败:", error);
      return [];
    }

    printFirst200Chars(contents);

    return contents;
  }

  async getEpisodeDanmuSegments(id) {
    log("info", "[iqiyi] 获取爱奇艺视频弹幕分段列表...", id);

    // 弹幕 API 基础地址
    const api_decode_base = "https://pcw-api.iq.com/api/decode/";
    const api_video_info = "https://pcw-api.iqiyi.com/video/video/baseinfo/";

    // 解析 URL 获取 tvid
    let tvid, originalTvid;
    try {
      const idMatch = id.match(/v_(\w+)/);
      if (!idMatch) {
        log("error", "[iqiyi] 无法从 URL 中提取 tvid");
        return new SegmentListResponse({
          "type": "qiyi",
          "segmentList": []
        });
      }
      tvid = idMatch[1];
      log("info", `[iqiyi] tvid: ${tvid}`);
      originalTvid = tvid; // 保存原始 tvid，用于解码失败回退

      // 获取 tvid 的解码信息
      const decodeUrl = `${api_decode_base}${tvid}?platformId=3&modeCode=intl&langCode=sg`;
      let res = await httpGet(decodeUrl, {
        headers: {
          "Content-Type": "application/json",
          "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      });
      const data = typeof res.data === "string" ? JSON.parse(res.data) : res.data;
      tvid = data.data.toString();
      log("info", `[iqiyi] 解码后 tvid: ${tvid}`);
    } catch (error) {
      log("error", "[iqiyi] 请求解码信息失败:", error);
      return new SegmentListResponse({
        "type": "qiyi",
        "segmentList": []
      });
    }

    // 获取视频基础信息
    let duration;
    try {
      const videoInfoUrl = `${api_video_info}${tvid}`;
      const res = await httpGet(videoInfoUrl, {
        headers: {
          "Content-Type": "application/json",
          "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      });
      const data = typeof res.data === "string" ? JSON.parse(res.data) : res.data;
      const videoInfo = data.data;
      duration = Number(videoInfo.durationSec) || 0;
      if (videoInfo.displayBarrage === false) {
        log("info", "[iqiyi] 爱奇艺视频未开启弹幕");
        return new SegmentListResponse({
          "type": "qiyi",
          "duration": duration,
          "segmentList": []
        });
      }
      log("info", `[iqiyi] 时长: ${duration}`);
    } catch (error) {
      log("error", "[iqiyi] 请求视频基础信息失败:", error);
    }

    // decode API 输出的 tvid 无效时（duration=0 或请求失败），用原始 tvid 重试
    if (!duration && originalTvid && originalTvid !== tvid) {
      log("info", `[iqiyi] decode 后 tvid 无效，用原始 tvid 重试: ${originalTvid}`);
      try {
        const retryUrl = `${api_video_info}${originalTvid}`;
        const retryRes = await httpGet(retryUrl, {
          headers: {
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
          bypassCache: true
        });
        const retryData = typeof retryRes.data === "string" ? JSON.parse(retryRes.data) : retryRes.data;
        const retryDuration = Number(retryData.data.durationSec) || 0;
        if (retryDuration > 0) {
          tvid = originalTvid;
          duration = retryDuration;
          log("info", `[iqiyi] 原始 tvid 有效，时长: ${duration}`);
        }
      } catch (retryError) {
        log("error", "[iqiyi] 原始 tvid 重试也失败:", retryError);
      }
    }
    if (!duration) {
      return new SegmentListResponse({
        "type": "qiyi",
        "segmentList": []
      });
    }

    // 当前爱奇艺弹幕分片按 60 秒切片，并使用 md5 后缀校验。
    const segmentDuration = 60;
    const page = Math.ceil(duration / segmentDuration);
    log("info", `[iqiyi] 弹幕分段数量: ${page}`);

    // 构建分段列表
    const segmentList = [];
    const paddedTvid = `0000${tvid}`;
    const bulletPath = `${paddedTvid.slice(-4, -2)}/${paddedTvid.slice(-2)}`;
    for (let i = 0; i < page; i++) {
      const pageNo = i + 1;
      const sign = md5(`${tvid}_${segmentDuration}_${pageNo}cbzuw1259a`).slice(-8);
      const api_url = `https://cmts.iqiyi.com/bullet/${bulletPath}/${tvid}_${segmentDuration}_${pageNo}_${sign}.br`;
      segmentList.push({
        "type": "qiyi",
        "segment_start": i * segmentDuration,
        "segment_end": Math.min((i + 1) * segmentDuration, duration),
        "url": api_url
      });
    }

    return new SegmentListResponse({
      "type": "qiyi",
      "duration": duration,
      "segmentList": segmentList
    });
  }

  async getEpisodeSegmentDanmu(segment) {
    try {
      const response = await httpGet(segment.url, {
        headers: {
          "Accept-Encoding": "br",
          "Content-Type": "application/octet-stream",
          "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
        base64Data: true,
        validStatusCodes: [404],
        retries: 1,
      });

      if (!response || response.status === 404 || !response.data) {
        return [];
      }

      const compressed = base64ToBytes(response.data);
      const payload = await this._decompressBrotli(compressed);

      if (payload[0] === 60) {
        return this._parseIqiyiXmlDanmu(utf8BytesToString(payload));
      }

      return this._parseIqiyiProtoDanmu(payload);
    } catch (error) {
      log("error", "[iqiyi] 请求分片弹幕失败:", error);
      return []; // 返回空数组而不是抛出错误，保持与getEpisodeDanmu一致的行为
    }
  }

  async _decompressBrotli(bytes) {
    return decompressBrotli(bytes);
  }

  _parseIqiyiXmlDanmu(xml) {
    function extract(tag) {
      const reg = new RegExp(`<${tag}>(.*?)</${tag}>`, "g");
      return xml.match(reg)?.map((x) => x.substring(tag.length + 2, x.length - tag.length - 3)) || [];
    }

    const danmaku = extract("content");
    const showTime = extract("showTime");
    const color = extract("color");
    const like = extract("likeCount");

    return danmaku.map((content, i) => ({
      content,
      showTime: showTime[i],
      color: color[i],
      like: parseInt(like[i], 10) || 0,
    }));
  }

  _parseIqiyiProtoDanmu(bytes) {
    const contents = [];
    const fields = this._parseIqiyiProtoFields(bytes);

    for (const field of fields) {
      if (field.number !== 6 || !field.bytes) continue;

      const danmuBlock = this._parseIqiyiProtoFields(field.bytes);
      const blockShowTime = this._getIqiyiProtoString(danmuBlock, 1);

      for (const itemField of danmuBlock) {
        if (itemField.number !== 2 || !itemField.bytes) continue;

        const item = this._parseIqiyiProtoFields(itemField.bytes);
        const content = this._getIqiyiProtoString(item, 2);
        if (!content) continue;

        contents.push({
          content,
          showTime: this._getIqiyiProtoString(item, 6) || blockShowTime || "0",
          color: this._getIqiyiProtoString(item, 8) || "ffffff",
          like: parseInt(this._getIqiyiProtoString(item, 14), 10) || 0,
        });
      }
    }

    return contents;
  }

  _parseIqiyiProtoFields(bytes) {
    const fields = [];
    let offset = 0;

    while (offset < bytes.length) {
      const keyResult = this._readIqiyiVarint(bytes, offset);
      const key = keyResult.value;
      offset = keyResult.offset;

      const number = Number(key >> 3n);
      const wireType = Number(key & 7n);
      if (number === 0) break;

      if (wireType === 0) {
        const valueResult = this._readIqiyiVarint(bytes, offset);
        fields.push({ number, wireType, value: valueResult.value.toString() });
        offset = valueResult.offset;
      } else if (wireType === 1) {
        fields.push({ number, wireType });
        offset += 8;
      } else if (wireType === 2) {
        const lengthResult = this._readIqiyiVarint(bytes, offset);
        const length = Number(lengthResult.value);
        offset = lengthResult.offset;
        const end = offset + length;
        if (end > bytes.length) break;

        const raw = bytes.subarray(offset, end);
        fields.push({ number, wireType, bytes: raw, value: utf8BytesToString(raw) });
        offset = end;
      } else if (wireType === 5) {
        fields.push({ number, wireType });
        offset += 4;
      } else {
        break;
      }
    }

    return fields;
  }

  _readIqiyiVarint(bytes, offset) {
    let value = 0n;
    let shift = 0n;
    let pos = offset;

    while (pos < bytes.length) {
      const byte = bytes[pos++];
      value |= BigInt(byte & 0x7f) << shift;
      if ((byte & 0x80) === 0) {
        return { value, offset: pos };
      }
      shift += 7n;
    }

    throw new Error("爱奇艺弹幕 protobuf varint 不完整");
  }

  _getIqiyiProtoString(fields, number) {
    return fields.find(field => field.number === number)?.value || "";
  }

  formatComments(comments) {
    return comments.map(item => {
      const content = {
          timepoint: 0,	// 弹幕发送时间（秒）
          ct: 1,	// 弹幕类型，1-3 为滚动弹幕、4 为底部、5 为顶端、6 为逆向、7 为精确、8 为高级
          size: 25,	//字体大小，25 为中，18 为小
          color: 16777215,	//弹幕颜色，RGB 颜色转为十进制后的值，16777215 为白色
          unixtime: Math.floor(Date.now() / 1000),	//Unix 时间戳格式
          uid: 0,		//发送人的 id
          content: "",
      };
      content.timepoint = parseFloat(item["showTime"]);
      content.color = parseInt(item["color"], 16);
      content.content = decodeHtmlEntities(item["content"]);
      content.size = 25;
      content.like = item["like"];
      return content;
    });
  }
}
